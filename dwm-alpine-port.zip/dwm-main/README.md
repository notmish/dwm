# notmish DWM setup — Alpine Linux port

This is an Alpine/OpenRC adaptation of the DWM setup in this repository. It keeps the patched DWM 6.8 and slstatus 1.1 sources, your DWM config/keybindings, Kitty config, Dunst config, GTK settings, wallpapers, and the dark monochrome color palette.

## Target system

- Alpine Linux x86_64, installed with `setup-alpine`
- Stable repositories only: the installed branch's `main` and `community`
- OpenRC + `doas` (no `sudo`, no systemd)
- Xorg + `startx` + DWM
- Dell Inspiron 5559 / Intel Core i5-6200U / Intel HD Graphics 520 + AMD Radeon R5 M335

The installer refuses to run if it sees an active `edge` or `testing` repository. It does not modify `/etc/apk/repositories`, switch branches, or run a system-wide `apk upgrade`.

## 1. Install the desktop

Extract this project, open a terminal in the extracted directory, then run as your normal user:

```sh
chmod +x auto-install-alpine.sh install-graphics-alpine.sh
./auto-install-alpine.sh
```

Do **not** run the script as root and do not prefix it with `doas`. It requests privilege through your existing `doas` setup.

The installer:

1. Updates the currently configured APK indexes.
2. Runs Alpine's `setup-xorg-base` when available (Xorg, `xinit`, eudev, libinput input driver and Mesa baseline).
3. Installs the build dependencies needed by DWM/slstatus on musl.
4. Installs desktop/audio/utilities from the currently enabled repositories. Optional package names are checked first; packages unavailable on that stable branch are skipped with a warning rather than causing the whole install to abort.
5. Installs available Intel/AMD firmware and Mesa drivers, plus OpenRC `elogind` session support when available.
6. Backs up existing dotfiles before copying this setup.
7. Rebuilds DWM and slstatus on the Alpine machine. Prebuilt `.o` files and binaries from other distros are deliberately excluded.

After the installer finishes, reboot, log in on a TTY as your regular user, and run:

```sh
startx
```

The DWM keybindings remain the same (Super is the Windows key):

| Key | Action |
|---|---|
| `Super + Enter` | Kitty |
| `Super + Space` | dmenu |
| `Super + b` | Toggle bar |
| `Super + q` | Close window |
| `Super + Shift + q` | Quit DWM |
| `Super + Left/Right` | Focus window |
| `Super + Shift + Enter` | Promote window to master |
| `Super + Tab` | Previous tag |
| `Super + Shift + Space` | Toggle floating |
| `Super + Alt + Up/Down` | Brightness up/down |
| `Super + Alt + Right/Left` | Volume up/down through `wpctl` |
| `Super + Print` | Full screenshot |
| `Super + Shift + Print` | Selective screenshot |

Screenshots are saved in `~/Pictures/screenshot/`. The config uses `maim` when present and falls back to `scrot` if that is what the stable branch provides.

## 2. Manual graphics/firmware setup

The main installer already attempts the graphics packages. To re-run only that part later:

```sh
./install-graphics-alpine.sh
```

### Intel HD Graphics 520 (Skylake)

- Kernel DRM driver: `i915` (part of the Linux kernel; there is no separate proprietary Intel GPU driver to install).
- OpenGL userspace: Mesa's `iris` driver, included in the Mesa Gallium DRI stack.
- Xorg display driver: start with the built-in `modesetting` DDX. Do not install `xf86-video-intel` just because the GPU is Intel; the old Intel DDX is not required for this setup.
- Firmware: `linux-firmware-i915` is the separate Intel graphics firmware package in Alpine's current split. `linux-firmware-intel` includes the Intel wireless firmware tree (including iwlwifi firmware for the AC 3160), but is a much larger download.
- Optional userspace packages: `mesa-vulkan-intel` for Vulkan and `intel-media-driver` only where that driver supports the specific codec/profile. The HD 520's main OpenGL path is Mesa Iris from `mesa-dri-gallium`.

### AMD Radeon R5 M335

The Linux kernel documentation groups the HD 8500M/8600M/R5 M335 series under the **HAINAN** code reference. The GPU is an older Southern Islands-era GCN part. The kernel offers the legacy `radeon` driver and the newer `amdgpu` driver for Southern Islands; do not force a driver switch before checking what the running kernel binds.

- Firmware: install `linux-firmware-radeon` (which pulls in AMDGPU firmware where required) and `linux-firmware-amdgpu` if both are available in your branch.
- OpenGL: `mesa-dri-gallium` provides Mesa's Gallium drivers; the Radeon userspace driver is selected by Mesa when the kernel DRM driver is working.
- Xorg: use the built-in `modesetting` driver first. An extra Radeon Xorg DDX is not normally necessary.
- Hybrid offload: test the dedicated GPU with `DRI_PRIME=1` as shown below. The Intel GPU can remain the desktop/display GPU while individual OpenGL applications are offloaded to Radeon.

### Verify that both GPUs are detected and accelerated

Install diagnostic tools if they were skipped:

```sh
doas apk add pciutils kmod mesa-utils
```

Reboot, then run:

```sh
lspci -nnk | grep -A3 -E 'VGA|3D|Display'
lsmod | grep -E '^(i915|radeon|amdgpu)'
dmesg | grep -iE 'i915|radeon|amdgpu|firmware' | tail -n 80
glxinfo -B
DRI_PRIME=1 glxinfo -B
```

What to look for:

- Intel HD 520 should show `Kernel driver in use: i915`.
- The Radeon should show either `radeon` or `amdgpu` as its kernel driver. A working device should not have a firmware-load failure in `dmesg`.
- `glxinfo -B` should report a Mesa Intel renderer when Intel is the default.
- `DRI_PRIME=1 glxinfo -B` should report the Radeon renderer if offload is working. You can start an application on the Radeon with `DRI_PRIME=1 application-name`.

If `glxinfo` is not found, install `mesa-utils` if available from the enabled stable repositories. If `DRI_PRIME=1` does not select the Radeon, inspect the `lspci -k` and `dmesg` output before changing kernel parameters.

### Optional: explicitly choose AMDGPU for the R5 M335

The Linux kernel documents `si_support` for first-generation GCN / Southern Islands devices and says that `amdgpu` and `radeon` must be configured in opposite directions. This is an **optional troubleshooting/experiment**, not the default installation path.

Before trying it, confirm all of the following:

1. `lspci -nnk` identifies the AMD GPU as the R5 M335/Hainan family (commonly PCI vendor/device ID `1002:6660`, with the exact revision depending on board).
2. The running kernel has `CONFIG_DRM_AMDGPU_SI` enabled.
3. `modinfo amdgpu` exposes the `si_support` parameter.

Only then create the options file:

```sh
doas sh -c 'cat > /etc/modprobe.d/r5-m335-amdgpu.conf <<EOF
options amdgpu si_support=1
options radeon si_support=0
EOF'
```

Reboot and inspect `lspci -k` and `dmesg` again. If it fails to initialize, remove `/etc/modprobe.d/r5-m335-amdgpu.conf` from a TTY/recovery environment and reboot. Do not enable both drivers for the same Southern Islands GPU. Keep the default `radeon` binding if it is stable and provides the performance you need.

### CPU, Wi-Fi, touchpad and audio

- **Intel Core i5-6200U:** no separate CPU driver is needed. The kernel handles CPU frequency scaling. `intel-ucode` may be available as a separate stable package for Intel microcode updates; installing the package alone does not prove that your bootloader loads its early microcode image.
- **Intel Wireless-AC 3160:** uses the in-kernel `iwlwifi` driver. Install `linux-firmware-intel` for its firmware files. If Wi-Fi is missing, check `lspci -nnk` and `dmesg | grep -i iwlwifi`.
- **Touchpad:** `setup-xorg-base` installs `xf86-input-libinput`; Xorg normally detects the touchpad automatically. For tapping, use an Xorg libinput configuration or `xinput` after login.
- **Audio:** the Intel HD Audio controller is handled by the kernel's `snd_hda_intel` driver. This setup uses PipeWire + WirePlumber in the D-Bus session; the DWM volume shortcuts call `wpctl`.
- **Brightness:** `brightnessctl` talks to the kernel backlight interface. If brightness keys fail, check `ls /sys/class/backlight/` and your user access to the device.

## 3. Alpine-specific differences from Arch

- `doas` replaces `sudo`; APK replaces pacman.
- Alpine uses musl and OpenRC. Both Makefiles now use Alpine's `/usr/include` and `/usr/lib` paths instead of Arch's `/usr/X11R6` paths.
- `.xinitrc` no longer calls `systemctl --user` or `dbus-update-activation-environment`. It launches DWM inside `dbus-run-session` and starts the PipeWire/WirePlumber user processes there.
- When available, the installer adds `elogind` + `elogind-openrc` and enables its OpenRC service. Elogind is a standalone session/seat manager; it does not install or switch the machine to systemd.
- `Materia-dark` is not installed from Alpine `testing`; the GTK config uses the built-in `Adwaita-dark` theme instead. This avoids enabling `testing` solely for the theme. Papirus and JetBrains Mono Nerd Font are installed only if they exist in the enabled stable branch.
- Bibata Modern Ice is downloaded from its upstream GitHub release, not from an Alpine repository. If the download fails, the desktop still works with the system cursor.
- `auto-install-arch.sh`, `pkglist-arch.txt`, `aurlist-arch.txt`, and `README-ARCH.md` preserve the original Arch-specific files. Do not execute the Arch installer on Alpine; use `auto-install-alpine.sh` and this guide.

## 4. Rebuilding after changing DWM/slstatus config

```sh
make -C ~/.config/suckless/dwm clean all
doas make -C ~/.config/suckless/dwm install
make -C ~/.config/suckless/slstatus clean all
doas make -C ~/.config/suckless/slstatus install
```

## Sources

- [Alpine Xorg wiki](https://wiki.alpinelinux.org/wiki/Xorg)
- [Alpine D-Bus wiki](https://wiki.alpinelinux.org/wiki/Dbus)
- [Alpine release branches](https://www.alpinelinux.org/releases/)
- [Linux kernel AMDGPU module parameters](https://docs.kernel.org/gpu/amdgpu/module-parameters.html)
- [Linux kernel AMDGPU ASIC information](https://docs.kernel.org/6.1/gpu/amdgpu/driver-misc.html)
