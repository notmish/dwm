/* See LICENSE file for copyright and license details. */

/* appearance */
static const unsigned int borderpx  = 2;        /* border pixel of windows */
static const unsigned int snap      = 32;       /* snap pixel */
static const int showbar            = 1;        /* 0 means no bar */
static const int topbar             = 1;        /* 0 means bottom bar */
static const char *fonts[]          = { "JetBrains Mono Nerd Font:size=12"};
static const char dmenufont[]       = "JetBrains Mono Nerd Font:size=12";
static const unsigned int systraypinning = 0;
static const unsigned int systrayonleft = 0;
static const unsigned int systrayspacing = 5;
static const int systraypinningfailfirst = 1;
static const int showsystray = 1;

/* color scheme: soft monochrome, Materia Dark inspired.
 * Deliberately avoids pure #000000 / #ffffff to cut glare and halation:
 * normal text ~9.6:1 contrast, selected text ~8.7:1 (easy on the eyes). */
static const char col_bg[]         = "#212121";  /* bar / window background (Materia Dark base) */
static const char col_fg[]         = "#c8c8c8";  /* normal text, soft light gray */
static const char col_border[]     = "#3a3a3a";  /* unfocused window border */
static const char col_sel_bg[]     = "#424242";  /* selected tag / title / dmenu highlight */
static const char col_sel_fg[]     = "#eeeeee";  /* selected text */
static const char col_sel_border[] = "#9e9e9e";  /* focused window border */

static const char *colors[][3] = {
    /*               fg          bg          border         */
    [SchemeNorm] = { col_fg,     col_bg,     col_border     },
    [SchemeSel]  = { col_sel_fg, col_sel_bg, col_sel_border },
};

/* tagging */
static const char *tags[] = { "1", "2", "3", "4", "5", "6" };

static const Rule rules[] = {
	/* xprop(1):
	 *	WM_CLASS(STRING) = instance, class
	 *	WM_NAME(STRING) = title
	 */
	/* class      instance    title       tags mask     isfloating   monitor */
	{ "Gimp",     NULL,       NULL,       0,            1,           -1 },
	{ "Firefox",  NULL,       NULL,       1 << 8,       0,           -1 },
};

/* layout(s) */
static const float mfact     = 0.55; /* factor of master area size [0.05..0.95] */
static const int nmaster     = 1;    /* number of clients in master area */
static const int resizehints = 1;    /* 1 means respect size hints in tiled resizals */
static const int lockfullscreen = 1; /* 1 will force focus on the fullscreen window */
static const int refreshrate = 120;  /* refresh rate (per second) for client move/resize */

static const Layout layouts[] = {
	/* symbol     arrange function */
	{ "",        tile },    /* first entry is default */
	{ "",        NULL },    /* no layout function means floating behavior */
	{ "󰍉",        monocle },
};

/* key definitions */
#define MODKEY Mod4Mask
#define TAGKEYS(KEY,TAG) \
	{ MODKEY,                       KEY,      view,           {.ui = 1 << TAG} }, \
	{ MODKEY|ControlMask,           KEY,      toggleview,     {.ui = 1 << TAG} }, \
	{ MODKEY|ShiftMask,             KEY,      tag,            {.ui = 1 << TAG} }, \
	{ MODKEY|ControlMask|ShiftMask, KEY,      toggletag,      {.ui = 1 << TAG} },

/* helper for spawning shell commands in the pre dwm-5.0 fashion */
#define SHCMD(cmd) { .v = (const char*[]){ "/bin/sh", "-c", cmd, NULL } }

/* commands */
static char dmenumon[2] = "0"; /* component of dmenucmd, manipulated in spawn() */
static const char *dmenucmd[] = {
    "dmenu_run",
    "-m", dmenumon,
    "-fn", dmenufont,

    "-nb", col_bg,
    "-nf", col_fg,
    "-sb", col_sel_bg,
    "-sf", col_sel_fg,

    NULL
};
static const char *termcmd[]  = { "kitty", NULL };

/* brightnessctl  */
static const char *brup[]   = { "sh", "-c", "brightnessctl set 10%+ && notify-send 'Brightness' \"$(brightnessctl get)\"", NULL };
static const char *brdown[] = { "sh", "-c", "brightnessctl set 10%- && notify-send 'Brightness' \"$(brightnessctl get)\"", NULL };

/* volume */
static const char *volup[] = {
  "sh", "-c",
  "wpctl set-volume @DEFAULT_AUDIO_SINK@ 5%+ && notify-send 'Volume' \"$(wpctl get-volume @DEFAULT_AUDIO_SINK@)\"",
  NULL
};

static const char *voldown[] = {
  "sh", "-c",
  "wpctl set-volume @DEFAULT_AUDIO_SINK@ 5%- && notify-send 'Volume' \"$(wpctl get-volume @DEFAULT_AUDIO_SINK@)\"",
  NULL
};

/* screenshot  */
static const char *screenshotcmd[] = {
    "sh", "-c",
    "mkdir -p \"$HOME/Pictures/screenshot\"; out=\"$HOME/Pictures/screenshot/screenshot-$(date +%F-%H-%M-%S).png\"; if command -v maim >/dev/null 2>&1; then maim \"$out\"; elif command -v scrot >/dev/null 2>&1; then scrot \"$out\"; else notify-send 'Screenshot' 'Install maim or scrot to enable screenshots'; fi",
    NULL
};

static const char *screenshotselectcmd[] = {
    "sh", "-c",
    "mkdir -p \"$HOME/Pictures/screenshot\"; out=\"$HOME/Pictures/screenshot/screenshot-$(date +%F-%H-%M-%S).png\"; if command -v maim >/dev/null 2>&1; then maim -s \"$out\"; elif command -v scrot >/dev/null 2>&1; then scrot -s \"$out\"; else notify-send 'Screenshot' 'Install maim or scrot to enable screenshots'; fi",
    NULL
};

static const Key keys[] = {
	/* modifier                     key        function        argument */
	{ MODKEY,                       XK_space,  spawn,          {.v = dmenucmd } },
	{ MODKEY,                       XK_Return, spawn,          {.v = termcmd } },
	{ MODKEY,                       XK_b,      togglebar,      {0} },
	{ MODKEY,                       XK_Right,  focusstack,     {.i = +1 } },
	{ MODKEY,                       XK_Left,   focusstack,     {.i = -1 } },
	{ MODKEY,                       XK_Down,   setmfact,       {.f = -0.05} },
	{ MODKEY,                       XK_Up,     setmfact,       {.f = +0.05} },
	{ MODKEY|ShiftMask,             XK_Return, zoom,           {0} },
	{ MODKEY,                       XK_Tab,    view,           {0} },
	{ MODKEY,                       XK_q,      killclient,     {0} },
	{ MODKEY|ShiftMask,             XK_space,  togglefloating, {0} },
	{ MODKEY,                       XK_0,      view,           {.ui = ~0 } },
	{ MODKEY|ShiftMask,             XK_0,      tag,            {.ui = ~0 } },
	{ MODKEY,                       XK_comma,  focusmon,       {.i = -1 } },
	{ MODKEY,                       XK_period, focusmon,       {.i = +1 } },
	{ MODKEY|ShiftMask,             XK_comma,  tagmon,         {.i = -1 } },
	{ MODKEY|ShiftMask,             XK_period, tagmon,         {.i = +1 } },
	TAGKEYS(                        XK_1,                      0)
	TAGKEYS(                        XK_2,                      1)
	TAGKEYS(                        XK_3,                      2)
	TAGKEYS(                        XK_4,                      3)
	TAGKEYS(                        XK_5,                      4)
	TAGKEYS(                        XK_6,                      5)
	{ MODKEY|ShiftMask,             XK_q,      quit,           {0} },
	{ MODKEY|Mod1Mask, 		XK_Up, 	   spawn, 	   {.v = brup } },
	{ MODKEY|Mod1Mask, 		XK_Down,   spawn, 	   {.v = brdown } },
	{ MODKEY|Mod1Mask, 		XK_Right,  spawn, 	   {.v = volup } },
	{ MODKEY|Mod1Mask, 		XK_Left,   spawn, 	   {.v = voldown } },
	{ MODKEY,           		XK_Print,  spawn, 	   {.v = screenshotcmd } },
	{ MODKEY|ShiftMask,  		XK_Print,  spawn, 	   {.v = screenshotselectcmd } },
};

/* button definitions */
/* click can be ClkTagBar, ClkLtSymbol, ClkStatusText, ClkWinTitle, ClkClientWin, or ClkRootWin */
static const Button buttons[] = {
	/* click                event mask      button          function        argument */
	{ ClkLtSymbol,          0,              Button1,        setlayout,      {0} },
	{ ClkLtSymbol,          0,              Button3,        setlayout,      {.v = &layouts[2]} },
	{ ClkWinTitle,          0,              Button2,        zoom,           {0} },
	{ ClkStatusText,        0,              Button2,        spawn,          {.v = termcmd } },
	{ ClkClientWin,         MODKEY,         Button1,        movemouse,      {0} },
	{ ClkClientWin,         MODKEY,         Button2,        togglefloating, {0} },
	{ ClkClientWin,         MODKEY,         Button3,        resizemouse,    {0} },
	{ ClkTagBar,            0,              Button1,        view,           {0} },
	{ ClkTagBar,            0,              Button3,        toggleview,     {0} },
	{ ClkTagBar,            MODKEY,         Button1,        tag,            {0} },
	{ ClkTagBar,            MODKEY,         Button3,        toggletag,      {0} },
};

