#!/bin/sh
# Alpine Linux port of the notmish DWM setup.
# Run as the normal desktop user from inside the extracted project directory.
# Uses only the active stable Alpine repositories (main + community).
set -eu

REPO_URL="https://github.com/notmish/dwm.git"
CURSOR_URL="https://github.com/ful1e5/Bibata_Cursor/releases/latest/download/Bibata-Modern-Ice.tar.xz"

log() { printf '\n\033[1;34m==>\033[0m %s\n' "$*"; }
warn() { printf '\n\033[1;33mwarning: \033[0m%s\n' "$*" >&2; }
die() { printf '\n\033[1;31merror: \033[0m%s\n' "$*" >&2; exit 1; }

[ "$(id -u)" -ne 0 ] || die "Run as your regular user, not root. The script uses doas for system changes."
command -v doas >/dev/null 2>&1 || die "doas is required but was not found."
command -v apk >/dev/null 2>&1 || die "This script is for Alpine Linux (apk was not found)."
[ -r /etc/alpine-release ] || die "/etc/alpine-release is missing; this does not look like Alpine Linux."
[ "$(apk --print-arch)" = "x86_64" ] || die "This port is currently written for x86_64 Alpine systems."

# Never add or silently migrate repositories. Refuse any active edge/testing line.
if grep -Ev '^[[:space:]]*(#|$)' /etc/apk/repositories | grep -E '/(edge|testing)(/|$)' >/dev/null 2>&1; then
    die "An active edge/testing repository was found in /etc/apk/repositories. Remove it first; this installer will not use edge/testing."
fi
if ! grep -Ev '^[[:space:]]*(#|$)' /etc/apk/repositories | grep -E '/community/?[[:space:]]*$' >/dev/null 2>&1; then
    die "The stable community repository is not enabled. Enable the matching vX.Y/community line, then rerun."
fi

log "Checking doas permissions"
doas true || die "doas authorization failed. Check /etc/doas.conf and your wheel-group membership."

# Use the current branch configured by setup-alpine. No branch is added or changed.
log "Refreshing the existing Alpine package indexes"
doas apk update

log "Installing Xorg, input and base build support"
if command -v setup-xorg-base >/dev/null 2>&1; then
    doas setup-xorg-base
else
    doas apk add --no-cache xorg-server xinit eudev xf86-input-libinput mesa-dri-gallium
fi

doas apk add --no-cache \
    git curl build-base pkgconf \
    libx11-dev libxft-dev libxinerama-dev fontconfig-dev freetype-dev \
    dbus

# Add only packages present in the currently enabled repositories. This keeps
# optional desktop extras from aborting the install on a minor branch mismatch.
install_available() {
    available=""
    missing=""
    for pkg in $*; do
        if doas apk search -x "$pkg" 2>/dev/null | grep -q .; then
            available="$available $pkg"
        else
            missing="$missing $pkg"
        fi
    done
    if [ -n "$available" ]; then
        # Intentional word splitting: apk expects one package argument per word.
        # shellcheck disable=SC2086
        doas apk add --no-cache $available
    fi
    if [ -n "$missing" ]; then
        warn "Not found in the enabled stable repositories (skipped):$missing"
    fi
}

log "Installing desktop applications, audio, fonts and utilities"
install_available \
    dmenu kitty picom dunst dunstify libnotify \
    maim scrot brightnessctl xwallpaper feh xrandr xrdb xclip \
    pipewire pipewire-alsa pipewire-pulse wireplumber alsa-utils elogind elogind-openrc \
    thunar thunar-archive-plugin file-roller xarchiver \
    gvfs gvfs-fuse gvfs-mtp tumbler ffmpegthumbnailer udisks2 xdg-user-dirs \
    7zip unrar unzip bash \
    font-jetbrains-mono-nerd font-jetbrains-mono papirus-icon-theme lxappearance \
    btop fastfetch lsd vim \
    brightnessctl-udev

log "Installing graphics firmware and Mesa drivers"
# These packages are hardware-specific and are also available through the
# separate install-graphics-alpine.sh helper in this bundle.
install_available \
    linux-firmware-i915 linux-firmware-intel linux-firmware-amdgpu linux-firmware-radeon \
    mesa-dri-gallium mesa-va-gallium mesa-vulkan-intel mesa-vulkan-ati \
    intel-media-driver intel-ucode pciutils kmod mesa-utils vulkan-tools

# OpenRC's system D-Bus is separate from the per-session D-Bus created below.
log "Enabling the system D-Bus service"
if [ -x /etc/init.d/dbus ]; then
    doas rc-update add dbus default || true
    doas rc-service dbus start || true
fi

# setup-xorg-base normally configures eudev. Make sure it is enabled where the
# service script exists (some Alpine installations already have it running).
if [ -x /etc/init.d/udev ]; then
    doas rc-update add udev default || true
    doas rc-service udev start || true
fi

# elogind is a standalone logind implementation, not systemd. It provides
# user-session/seat handling used by desktop apps and Xorg on OpenRC systems.
if [ -x /etc/init.d/elogind ]; then
    doas rc-update add elogind default || true
    doas rc-service elogind start || true
fi

# Device-node access for DRM, brightness and audio. Add only groups that exist.
USER_NAME="$(id -un)"
for group in video input audio; do
    if grep -q "^${group}:" /etc/group; then
        doas addgroup "$USER_NAME" "$group" || true
    fi
done

log "Backing up and installing the desktop configuration"
STAMP="$(date +%Y%m%d-%H%M%S)"
backup_one() {
    target="$1"
    if [ -e "$target" ] || [ -L "$target" ]; then
        cp -a "$target" "${target}.backup.${STAMP}"
    fi
}

SRC="$(CDPATH= cd -- "$(dirname -- "$0")" && pwd)"
TMP_CLONE=""
if [ ! -d "$SRC/suckless/dwm" ] || [ ! -d "$SRC/suckless/slstatus" ]; then
    command -v git >/dev/null 2>&1 || die "The project files are missing and git is unavailable."
    TMP_CLONE="$(mktemp -d)"
    log "Local source tree not found; cloning $REPO_URL"
    git clone --depth 1 "$REPO_URL" "$TMP_CLONE/repo"
    SRC="$TMP_CLONE/repo"
fi

mkdir -p "$HOME/.config"
for item in dunst kitty gtk-3.0; do
    if [ -d "$SRC/.config/$item" ]; then
        backup_one "$HOME/.config/$item"
        rm -rf "$HOME/.config/$item"
        cp -a "$SRC/.config/$item" "$HOME/.config/$item"
    fi
done

backup_one "$HOME/.config/suckless"
rm -rf "$HOME/.config/suckless"
cp -a "$SRC/suckless" "$HOME/.config/suckless"

backup_one "$HOME/.xinitrc"
cp -a "$SRC/.xinitrc" "$HOME/.xinitrc"
chmod 755 "$HOME/.xinitrc"
backup_one "$HOME/.Xresources"
cp -a "$SRC/.Xresources" "$HOME/.Xresources"
if [ -f "$SRC/.bashrc" ]; then
    backup_one "$HOME/.bashrc"
    cp -a "$SRC/.bashrc" "$HOME/.bashrc"
fi

# Merge wallpaper files without deleting or overwriting the user's own images.
mkdir -p "$HOME/Wallpaper"
cp -an "$SRC/Wallpaper/." "$HOME/Wallpaper/"

log "Building DWM and slstatus natively on Alpine/musl"
make -C "$HOME/.config/suckless/dwm" clean all
doas make -C "$HOME/.config/suckless/dwm" install
make -C "$HOME/.config/suckless/slstatus" clean all
doas make -C "$HOME/.config/suckless/slstatus" install

if command -v xdg-user-dirs-update >/dev/null 2>&1; then
    xdg-user-dirs-update || true
fi
if command -v fc-cache >/dev/null 2>&1; then
    fc-cache -f || true
fi

log "Installing the Bibata cursor theme (upstream release; not an Alpine repo)"
CURSOR_TMP="$(mktemp -d)"
if curl -fL "$CURSOR_URL" -o "$CURSOR_TMP/bibata.tar.xz"; then
    mkdir -p "$HOME/.local/share/icons"
    tar -xJf "$CURSOR_TMP/bibata.tar.xz" -C "$HOME/.local/share/icons" --no-same-owner || warn "Bibata archive extraction failed; install the cursor manually."
else
    warn "Could not download Bibata. DWM itself is already installed; the default cursor will be used."
fi
rm -rf "$CURSOR_TMP"
[ -z "$TMP_CLONE" ] || rm -rf "$TMP_CLONE"

cat <<'DONE'

DWM setup installed.

Next:
  1. Reboot (so firmware, udev and group membership are applied).
  2. Log in on a TTY as your normal user.
  3. Run: startx

Main keybindings (Super = Windows key):
  Super+Enter            Kitty
  Super+Space            dmenu
  Super+q                Close window
  Super+Shift+q          Quit DWM
  Super+Alt+Up/Down      Brightness
  Super+Alt+Right/Left   Volume (PipeWire/wpctl)
  Super+Print            Full screenshot
  Super+Shift+Print      Select screenshot area

If a package was skipped, inspect the warning above and run:
  doas apk search -x PACKAGE_NAME

This installer did not add or enable edge/testing repositories.
DONE
