#!/bin/sh
# Graphics/firmware setup for Intel Skylake + AMD Radeon HAINAN hybrid laptops.
# Run as a regular user. This installs userspace drivers and firmware only;
# the kernel's i915/radeon/amdgpu DRM drivers are already part of the kernel.
set -eu

log() { printf '\n\033[1;34m==>\033[0m %s\n' "$*"; }
warn() { printf '\n\033[1;33mwarning: \033[0m%s\n' "$*" >&2; }
die() { printf '\n\033[1;31merror: \033[0m%s\n' "$*" >&2; exit 1; }

[ "$(id -u)" -ne 0 ] || die "Run as your regular user; this helper uses doas."
command -v doas >/dev/null 2>&1 || die "doas not found."
command -v apk >/dev/null 2>&1 || die "apk not found; this is for Alpine Linux."
[ "$(apk --print-arch)" = "x86_64" ] || die "This helper targets x86_64."
if grep -Ev '^[[:space:]]*(#|$)' /etc/apk/repositories | grep -E '/(edge|testing)(/|$)' >/dev/null 2>&1; then
    die "Active edge/testing repository detected. Remove it; this helper will not use it."
fi

doas true || die "doas authorization failed."
doas apk update

available=""
missing=""
for pkg in \
    mesa-dri-gallium mesa-va-gallium mesa-vulkan-intel mesa-vulkan-ati \
    linux-firmware-i915 linux-firmware-intel linux-firmware-amdgpu linux-firmware-radeon \
    intel-media-driver intel-ucode pciutils kmod mesa-utils vulkan-tools
 do
    if doas apk search -x "$pkg" 2>/dev/null | grep -q .; then
        available="$available $pkg"
    else
        missing="$missing $pkg"
    fi
done

[ -z "$available" ] || {
    # Intentional word splitting for apk's package arguments.
    # shellcheck disable=SC2086
    doas apk add --no-cache $available
}
[ -z "$missing" ] || warn "Not present in the enabled stable repositories (skipped):$missing"

for group in video input; do
    if grep -q "^${group}:" /etc/group; then
        doas addgroup "$(id -un)" "$group" || true
    fi
done

cat <<'INFO'

Installed available Intel/AMD Mesa drivers and firmware.
Reboot before testing. Then use:

  lspci -nnk | grep -A3 -E 'VGA|3D|Display'
  lsmod | grep -E '^(i915|radeon|amdgpu)'
  dmesg | grep -iE 'i915|radeon|amdgpu|firmware' | tail -n 80
  glxinfo -B
  DRI_PRIME=1 glxinfo -B

Expected mapping for this machine:
  Intel HD Graphics 520: i915 kernel driver + Mesa Iris (OpenGL).
  Radeon R5 M335: HAINAN-family discrete GPU; the kernel may bind radeon or
  amdgpu depending on kernel configuration/parameters. Mesa's Gallium stack
  supplies the OpenGL userspace driver. DRI_PRIME=1 tests offload to the dGPU.

Do not install the old xf86-video-intel DDX just because the GPU is Intel.
Xorg's built-in modesetting DDX is the default starting point. The DRM kernel
modules are not separately installed with an Xorg DDX package.

For an optional Southern Islands amdgpu experiment, first verify that the
running kernel has CONFIG_DRM_AMDGPU_SI enabled and that modinfo amdgpu lists
si_support. The kernel docs say SI cards can use either radeon or amdgpu and
that their support parameters must be set in opposite directions. Only then,
if the default radeon driver is inadequate, create:

  doas sh -c 'cat > /etc/modprobe.d/r5-m335-amdgpu.conf <<EOF
options amdgpu si_support=1
options radeon si_support=0
EOF'

Reboot and re-check lspci -k and dmesg. If the display fails or firmware errors
appear, remove that file from a TTY/recovery environment and reboot. Do not
set both drivers to claim the same Southern Islands device.
INFO
