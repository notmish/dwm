#!/bin/sh
# common.sh - shared helpers for the alpine-dwm scripts.
# SOURCE this file (". path/to/common.sh"); do not execute it.
#
# CONTRACT: the calling script must set SCRIPT_DIR to its own directory
# BEFORE sourcing this file. From SCRIPT_DIR we walk upward until we find the
# alpine-dwm root (a directory that contains both "pkglist" and "scripts").
# Nothing here depends on the current working directory or on a username.

: "${SCRIPT_DIR:?common.sh: the caller must set SCRIPT_DIR first}"

# Walk up from $1 until a directory containing pkglist/ and scripts/ is found.
_find_alpine_dir() {
    _d=$1
    while [ "$_d" != "/" ]; do
        if [ -d "$_d/pkglist" ] && [ -d "$_d/scripts" ]; then
            printf '%s\n' "$_d"
            return 0
        fi
        _d=$(dirname "$_d")
    done
    return 1
}

ALPINE_DIR=$(_find_alpine_dir "$SCRIPT_DIR") || {
    printf 'error: cannot find the alpine-dwm root above %s\n' "$SCRIPT_DIR" >&2
    exit 1
}
REPO_ROOT=$(dirname "$ALPINE_DIR")     # e.g. ~/dwm
PKGLIST_DIR=$ALPINE_DIR/pkglist        # e.g. ~/dwm/alpine-dwm/pkglist
CONFIGS_DIR=$ALPINE_DIR/configs        # e.g. ~/dwm/alpine-dwm/configs
SCRIPTS_DIR=$ALPINE_DIR/scripts

# ---- logging (plain text; no colour codes) ---------------------------------
say()  { printf '==> %s\n' "$*"; }
warn() { printf 'warning: %s\n' "$*" >&2; }
die()  { printf 'error: %s\n' "$*" >&2; exit 1; }

# ---- manifests -------------------------------------------------------------
# Print package names from a manifest: drops '#' comments and blank lines.
read_manifest() {
    [ -r "$1" ] || die "cannot read manifest: $1"
    sed -e 's/#.*//' -e 's/^[[:space:]]*//' -e 's/[[:space:]]*$//' "$1" | grep -v '^$'
}
