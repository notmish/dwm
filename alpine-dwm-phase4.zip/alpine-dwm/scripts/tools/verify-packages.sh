#!/bin/sh
# verify-packages.sh - READ-ONLY availability check against YOUR configured
# Alpine repositories. It installs nothing and changes nothing.
#
# Usage (explicit path; run as your normal user):
#   sh ~/dwm/alpine-dwm/scripts/tools/verify-packages.sh            # every pkglist/*.txt
#   sh ~/dwm/alpine-dwm/scripts/tools/verify-packages.sh audio.txt  # one manifest
# Run "doas apk update" first so the package index is current.

set -u
SCRIPT_DIR=$(cd "$(dirname "$0")" && pwd -P)
. "$SCRIPT_DIR/../lib/common.sh"

command -v apk >/dev/null 2>&1 || die "apk not found - run this on Alpine"

say "Alpine release : $(cat /etc/alpine-release 2>/dev/null || echo unknown)"
say "Architecture   : $(apk --print-arch)"
say "Repositories   :"
grep -v '^#' /etc/apk/repositories | sed 's/^/      /'
echo

ok=0; miss=0; bad=0

check_pkg() {
    _p=$1
    _hit=$(apk search -e "$_p" 2>/dev/null | head -n 1)
    if [ -z "$_hit" ]; then
        printf 'MISS  %-30s (not found in configured repos)\n' "$_p"
        miss=$((miss + 1))
        return
    fi
    # Which repo serves it? Look at the last path component of repo URLs.
    _repo=$(apk policy "$_p" 2>/dev/null | grep -Eo '/(main|community|testing)$' | sort -u | tr -d '/' | tr '\n' ',' | sed 's/,$//')
    [ -n "$_repo" ] || _repo='?'
    _inst=''
    apk info -e "$_p" >/dev/null 2>&1 && _inst=' [installed]'
    case $_repo in
        *testing*) printf 'BAD   %-30s %s (testing is forbidden)\n' "$_p" "$_hit"; bad=$((bad + 1)) ;;
        *)         printf 'OK    %-30s %-10s %s%s\n' "$_p" "$_repo" "$_hit" "$_inst"; ok=$((ok + 1)) ;;
    esac
}

if [ $# -eq 0 ]; then
    set -- "$PKGLIST_DIR"/*.txt
fi

for m in "$@"; do
    case $m in
        */*) f=$m ;;
        *)   f=$PKGLIST_DIR/$m ;;
    esac
    say "manifest: $(basename "$f")"
    for pkg in $(read_manifest "$f"); do
        check_pkg "$pkg"
    done
    echo
done

say "summary: ok=$ok missing=$miss testing=$bad"
[ "$miss" -eq 0 ] && [ "$bad" -eq 0 ]
